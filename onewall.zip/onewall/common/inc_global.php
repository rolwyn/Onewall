<?php

	$host 		=  	$_SERVER['HTTP_HOST']; // Host name to display if required.
	if($host == "www.onewall.com" || $host == "www.onewall.info") {
		$proto = "https";
	} else {
		$proto = "http";
	}
	$pageURL 	= $proto."://".$host.$_SERVER['REQUEST_URI'];
	$fUrl 		= $proto."://".$host."/";

	$username = "gshinfo";
	$password = "JunoShabbyMoody123#";

	if($pageName != "postPayment" && ($host == "onewall.info" || $host == "www.onewall.info")) {
		if($_SERVER['PHP_AUTH_USER'] != $username || $_SERVER['PHP_AUTH_PW'] != $password) {

			header('WWW-Authenticate: Basic realm="My Realm"');
		  	header('HTTP/1.0 401 Unauthorized');
		  	die ("Not authorized");
		}

		if (isset($_SERVER["HTTP_X_FORWARDED_PROTO"]) && $_SERVER["HTTP_X_FORWARDED_PROTO"] != "https") {
     	   header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    	}
	}

	// Extracting URL valuse
	$args 		= explode("/",$_SERVER['REQUEST_URI']);
	extract($_GET);
	$p1 = (trim($p1) != "") ? trim($p1) : trim($args[1]) ;
	$p2 = (trim($p2) != "") ? trim($p2) : trim($args[2]) ;
	$p3 = (trim($p3) != "") ? trim($p3) : trim($args[3]) ;
	$p4 = (trim($p4) != "") ? trim($p4) : trim($args[4]) ;
	$p5 = (trim($p5) != "") ? trim($p5) : trim($args[5]) ;


	/* ==============================
	=	Require a file for AppCode
	=============================== */

	require_once(__DIR__ . '/../config/global_appcodes.php');
	require_once(__DIR__ . '/../config/functions.php');
	
	// Common Confic

	// $commonBtnText 	= "Belong Here"; // Button to be disply on booking card.
	// $appCode 		= "WEBSITE";	// AppCode to identify the traffic of Web.
	// $companyName 	= "GetSetHome"; // Company name
	// $rupeeIcon 		= "&#8377;"; // Rupees icon using HTML
	// $strHelpLine   	= "8080 900 300"; // HelpLine #
	// $prLinkName		= "properties";


	/*===============================================
	=            DEFINE GLOBAL VARIABLE CONSTANT    =
	===============================================*/

	$jv 	= 212;
	$cv 	= 186;

	if (!defined('COMMON_JS')) {
		define('COMMON_JS', fnGetScriptFileName('/js/common.js'));
	}

	if (!defined('COMPANY_NAME')) {
		define('COMPANY_NAME', 'One Wall');
	}
	
	if (!defined('RUPEE_ICON')) {
		define('RUPEE_ICON', '&#8377;');
	}
	
	if (!defined('HELPLINE_NO')) {
		define('HELPLINE_NO', '8080 900 300');
	}
	
	if (!defined('CONTACT_EMAIL')) {
		define('CONTACT_EMAIL', 'contact.us@getsethome.com');
	}

	if (!defined('JS_PATH')) {
		define('JS_PATH', '/assets/js/');
	}

	if (!defined('CSS_PATH')) {
		define('CSS_PATH', '/assets/css/');
	}

	if (!defined('ICON_PATH')) {
		define('ICON_PATH', '/assets/icon/');
	}	

	if (!defined('IMG_PATH')) {
        // define('IMG_PATH', 'https://d3lpc2ltym46jt.cloudfront.net/img/');
        define('IMG_PATH', '/assets/img/');
    }

	if (!defined('VIDEO_PATH')) {
        // define('VIDEO_PATH', 'https://d3lpc2ltym46jt.cloudfront.net/video/');
        define('VIDEO_PATH', '/assets/video/');
    }

	// GETTING THE CONFIGPATH
	if(!defined('CONFIG_PATH')) {
		define('CONFIG_PATH', __DIR__ . '/../config/');
	}

	// GETTING THE CONFIGPATH
	if(!defined('Map_API')) {
		define('Map_API', 'AIzaSyBZsOwKrwBP3yRQO1wOYgFHe-1zc6DQBOs');
	}

	/*=====  End of DEFINE GLOBAL VARIABLE CONSTANT  ======*/
	
	if ($host == "onewall.local" || $host == "onewall.info" || $host == "www.onewall.info") {
		$apiUrl			= "http://".$host."/api/";
	} else {
		$apiUrl			= "https://".$host."/api/";
	}
	
	$inc_path			= __Dir__."/";
	$css_path			= "/assets/css/";

	$isRegionSel		= false;

	$blnBlog			= 0;
?>