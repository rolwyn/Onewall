<header class="pg_header">
	<nav class="navBar">
		<a class="nav_logo">
			<span class="home_logo">Hello</span>
		</a>
		<ul class="nav_links">
			<li class="nav_elements">
				<a href="">Shop</a>
				<div class="shop_list">
					<ul>
						<li>
							<a href="">ART FRAMES</a>
						</li>
						<li>
							<a href="">ART LAMPS</a>
						</li>
					</ul>
				</div>
			</li>
			<li class="nav_elements">
				<a href="">Philosophy</a>
			</li>
			<li class="nav_elements">
				<a href="">#onewallstories</a>
			</li>
			<li class="nav_elements">
				<a href="">How it Works</a>
			</li>
			<li class="nav_elements">
				<a href="">Contact</a>
			</li>
			<li class="search_element">
				<input type="text" class="searchbox" name="search">
				<span class="iconSearch">
					<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
			            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-searching-magnifying-glass"></use>
			        </svg>
				</span>
			</li>
			<li class="nav_rightelem _right _signinline">
				<a href="">Sign In</a>
			</li>
			<li class="nav_rightelem _right">
				<a href="">Login</a>
			</li>
			<li class="nav_rightelem _right">
				<a href="">
					<span class="iconHeart">
					<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
			            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-heart-outline"></use>
			        </svg>
				</span>
				</a>
				<a href="">
					<span class="iconCart">
					<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
			            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-shopping-cart"></use>
			        </svg>
				</span>
				</a>
			</li>
		</ul>
	</nav>
</header>