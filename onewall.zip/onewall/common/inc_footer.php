<footer class="footer_wrapper">
	<div class="footer_main">
		<div class="footer_inner">
			<aside class="footer_block">
				<div class="_box _sales">
					<h5>Business Sales</h5>
					<a href="#">Call our Representative</a>
				</div>
				<div class="_box">
					<h5>About Onewall</h5>
					<ul>
						<li>
							<a href="#">Our Company</a>
						</li>
						<li>
							<a href="#">Work with us</a>
						</li>
						<li>
							<a href="#">Blog</a>
						</li>
					</ul>
				</div>
			</aside>

			<aside class="footer_block">
				<div class="_box">
					<h5>Customer Service</h5>
					<ul>
						<li>
							<a href="#">Contact Us</a>
						</li>
						<li>
							<a href="#">Ordering</a>
						</li>
						<li>
							<a href="#">Shipping &amp; Delivery</a>
						</li>
						<li>
							<a href="#">Returns</a>
						</li>
						<li>
							<a href="#">FAQ</a>
						</li>
					</ul>
					<div class="_box _download">
						<a class="account_links" href="#">Download the App</a>
					</div>
				</div>
			</aside>
			<aside class="footer_block">
				<div class="_box _account">
					<ul>
						<li>
							<a class="account_links" href="#">My Account</a>
						</li>
						<li>
							<a class="account_links" href="#">Access My Account</a>
						</li>
						<li>
							<a class="account_links" href="#">Track My Order</a>
						</li>
						<li>
							<a class="account_links" href="#">Wishlist</a>
						</li>
						<li>
							<div class="_box _socialicons">
								<a class="share_icon" href="">
									<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
							            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-share"></use>
							        </svg>
								</a>
								<a class="fb_icon" href="">
									<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
							            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-facebook-app-logo"></use>
							        </svg>
								</a>
								<a class="instagram_icon" href="">
									<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
							            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-instagram-logo"></use>
							        </svg>
								</a>	
							</div>
						</li>
						<!-- Social Icons(add later) -->
					</ul>
				</div>
			</aside>
			<aside class="footer_block">
				<div class="_box _emailer">
					<h5>Signup for Emailer</h5>
					<input type="text" name="emailer" class="emailer">
				</div>
			</aside>
		</div>
	</div>
		<div class="footer_copyright">
			<span class="c_symbol">&copy;&nbsp;</span><span class="c_text">Onewall</span>
			<p>Young art, everchanging art, one wall stories are registered trademarks of Onewall Monkey pvt ltd</p>
		</div>
</footer>