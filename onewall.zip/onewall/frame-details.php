<?php
	require_once("./common/inc_global.php");
	require_once(CONFIG_PATH . 'curl.php');
	require_once(CONFIG_PATH . 'functions.php');

	// $css_script_path 	= fnGetScriptFileName(CSS_PATH.'home.css');
	// $js_script_path 	= fnGetScriptFileName(JS_PATH.'home.js');
	$css_script_path 	= CSS_PATH.'frame-details.css';
	// $js_script_path 	= JS_PATH.'frame_list.js';
	$icon_path			= ICON_PATH;
	$img_path			= IMG_PATH;
?>
<!DOCTYPE HTML>
<html lang="en">
	<head>
		<title><?php echo COMPANY_NAME ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="<?php echo $css_script_path; ?>" rel="stylesheet" type="text/css">
	</head>
	<body class="frame_details">
		<?php require_once $inc_path.'inc_header.php'; ?>
		<div class="shopping_cart">
			<div class="cart_section _checkout">
				<div class="checkout_container">
					<h1>SHOPPING CART</h1>
					<span class="__exit">X</span>
					<div class="__pdbutton">
						<input type="button" class="checkout_btn" name="procheckout" value="Add to Cart" id="protocheck"/>
						<span class="__right_arrow">
							<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
					            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-arrow-point-to-right"></use>
					        </svg>
						</span>
					</div>
					<div class="item_preview">
						<div class="product_section">
							<img class="__frame" src="<?php echo $img_path; ?>frame1.png" alt="">
							<img class="__image" src="<?php echo $img_path; ?>temple.png" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="pd_section _productdetails">
			<div class="wrapper">
				<div class="pd_container">
					<div class="pd_img">
						<div class="product_section">
							<img class="__frame" src="<?php echo $img_path; ?>frame1.png" alt="">
							<img class="__image" src="<?php echo $img_path; ?>temple.png" alt="">
						</div>
						<div class="__dots">
							<span id="cframe_img1" class="cframe_dot _col1"></span>
							<span id="cframe_img2" class="cframe_dot _col2"></span>
							<span id="cframe_img3" class="cframe_dot _col3"></span>
							<span id="cframe_img4" class="cframe_dot _col4"></span>
							<span id="cframe_img5" class="cframe_dot _col5"></span>
							<span id="cframe_img6" class="cframe_dot _col6"></span>
						</div>
					</div>
					<div class="pd_text">
						<div class="__inner">
							<h2 class="chead">Girl Power Pop Print</h2>
							<h2 class="chead">Rs.895</h2>
							<p class="cbody">A Chumbak Original, the Tiger Miniature Wall Art represents brilliant re-imaginations of the world around us. It has been created especially for you, printed on 100% acid.</p>
							<p class="cbody">Size: <br> Width (cms.): 15.2 Length (cms.): 22.9</p>
						</div>
						<div class="__pdbutton">
							<input type="button" class="viewall" name="viewall" value="Add to Cart" id="addcart"/>
							<input type="button" class="viewall" name="viewall" value="Buy Now" id="buyframe"/>
						</div>
						<div class="__inner">
							<p class="cbody">Delivery Options Available <br> Return within 20 days of placing an order <br> Get free delivery above Rs.999</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php require_once $inc_path.'inc_footer.php'; ?>
		<!-- <script src="<?php echo $js_script_path; ?>"></script> -->
	</body>
</html>