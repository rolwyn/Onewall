<?php
	require_once("./common/inc_global.php");
	require_once(CONFIG_PATH . 'curl.php');
	require_once(CONFIG_PATH . 'functions.php');

	// $css_script_path 	= fnGetScriptFileName(CSS_PATH.'home.css');
	// $js_script_path 	= fnGetScriptFileName(JS_PATH.'home.js');
	$css_script_path 	= CSS_PATH.'frame-details.css';
	// $js_script_path 	= JS_PATH.'frame_list.js';
	$icon_path			= ICON_PATH;
	$img_path			= IMG_PATH;
?>
<!DOCTYPE HTML>
<html lang="en">
	<head>
		<title>OneWall</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="<?php echo $css_script_path; ?>" rel="stylesheet" type="text/css">
	</head>
	<body class="frame_details">
		<?php require_once $inc_path.'inc_header.php'; ?>
		
		<!-- <script src="<?php echo $js_script_path; ?>"></script> -->
	</body>
</html>