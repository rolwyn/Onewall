<!-- <?php
	// error_reporting(0);
	// error_reporting(E_ALL);
	// ini_set("display_errors", 1);
	require_once(__DIR__ . '/../config/variables.php');
	require_once(CONFIG_PATH .'functions.php');


	extract($_REQUEST);
	$cmd = $_REQUEST['cmd'];

	
	switch ($cmd) {

		case 'TEST'		:		fnGetScriptFileName();
								break;

		default 		:		echo "Error, please try again";
								break;
	}
?> -->