<?php
	require_once("./common/inc_global.php");
	require_once(CONFIG_PATH . 'curl.php');
	require_once(CONFIG_PATH . 'functions.php');

	// $css_script_path 	= fnGetScriptFileName(CSS_PATH.'home.css');
	// $js_script_path 	= fnGetScriptFileName(JS_PATH.'home.js');
	$css_script_path 	= CSS_PATH.'home.css';
	$js_script_path 	= JS_PATH.'home.js';
	$icon_path			= ICON_PATH;
	$img_path			= IMG_PATH;
?>
<!DOCTYPE HTML>
<html lang="en">
	<head>
		<title>OneWall</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="<?php echo $css_script_path; ?>" rel="stylesheet" type="text/css">
	</head>
	<body class="home_page">
		<?php require_once $inc_path.'inc_header.php'; ?>
		<div class="intro_wrapper">
			<div class="innerblock_top">
				<h2 class="chead">say hello to <br> everchanging art</h2>
				<span class="cbody">flirt with art, move on when <br> you're bored. #youngart</span>
			</div>
			<div class="innerblock_bot">
				<h2 class="chead">what colour floats your boat?</h2>
				<span class="cbody">frames in 5 colours <br> turmeric | peacock | post box | ink | snow</span>
			</div>

			<div class="innerblock_center">
				<div class="cframes">
				<img  class="actFrame" src="<?php echo $img_path; ?>frame1.png" alt="">
				</div>
				<div class="cimages">
					<img class="frameImage" src="<?php echo $img_path; ?>temple.png" alt="">
				</div>
				<div class="cframe_dots">
					<span id="cframe_img1" class="cframe_dot _col1"></span>
					<span id="cframe_img2" class="cframe_dot _col2"></span>
					<span id="cframe_img3" class="cframe_dot _col3"></span>
					<span id="cframe_img4" class="cframe_dot _col4"></span>
					<span id="cframe_img5" class="cframe_dot _col5"></span>
					<span id="cframe_img6" class="cframe_dot _col6"></span>
				</div>
			</div>

			<div class="innerblock_right">
				<h2 class="chead">pick something <br> you fancy!</h2>
				<span class="cbody">new day new art, <br> there's never a dull day here. <br> now keep changing your art <br> with a simple click-magnet lock!</span>
			</div>
			<div class="right_slider">
				<div class="rslider_container">
					<div class="rslider">
						<img class="rsliderimage" src="<?php echo $img_path; ?>abstract.jpg" alt="">
					</div>
					<div class="rslider">
					<img class="rsliderimage" src="<?php echo $img_path; ?>cat.jpg" alt="">
					</div>
					<div class="rslider">
					<img class="rsliderimage" src="<?php echo $img_path; ?>girl.jpeg" alt="">
					</div>
					<div class="rslider">
					<img class="rsliderimage" src="<?php echo $img_path; ?>mario.png" alt="">
					</div>
					<div class="rslider">
					<img class="rsliderimage" src="<?php echo $img_path; ?>cat.jpg" alt="">
					</div>
				</div>
				<span class="top_arrow">
					<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
			            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-navigate-up-arrow"></use>
			        </svg>
				</span>
				<span class="bot_arrow">
					<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
			            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-arrow-down-sign-to-navigate"></use>
			        </svg>
				</span>
			</div>
		</div>

		<div class="shop_wrapper">
			<div class="left_half">
				<div class="inner_left">
					<div class="svg_frame">
						<img class="svg_frameImg" src="<?php echo $img_path; ?>leftframe.png" alt="">
					</div>
					<div class="inner_text">
						<h1>Art Frames</h1>
						<span>Ever-Changing Art</span>
					</div>
					<div class="view_button">
						<input type="button" class="viewall" name="viewall" value="View All" id="framesubmit"/>
					</div>
				</div>
			</div>
			<div class="right_half">
				<div class="inner_right">
					<div class="svg_frame">
						<img class="svg_frameImg" src="<?php echo $img_path; ?>lamp.png" alt="">
					</div>
					<div class="inner_text">
						<h1>LampShades</h1>
						<span>Light Up Your Space</span>
					</div>
					<div class="view_button">
						<input type="button" class="viewall" name="viewall" value="View All" id="lampsubmit"/>
					</div>
				</div>
			</div>
		</div>

		<div class="stories_wrapper">
			<div class="inner_center">
				<div class="innerContent">
					<div class="head_text">
						<h2 class="storyHeader">#onewallstories</h2>
					</div>
					<div class="story_frames">
						<div class="sframe">
							<img class="sframe_img" src="<?php echo $img_path; ?>frame1.png" alt="">
						</div>
						<div class="backimage">
							<img class="backimage_img" src="<?php echo $img_path; ?>Rajasthan1.png" alt="">
						</div>
					</div>
					<div class="story_frames">
						<div class="sframe">
							<img class="sframe_img" src="<?php echo $img_path; ?>frame1.png" alt="">
						</div>
						<div class="backimage">
							<img class="backimage_img" src="<?php echo $img_path; ?>Rajasthan2.png" alt="">
						</div>
					</div>
					<div class="story_frames">
						<div class="sframe">
							<img class="sframe_img" src="<?php echo $img_path; ?>frame1.png" alt="">
						</div>
						<div class="backimage">
							<img class="backimage_img" src="<?php echo $img_path; ?>Rajasthan3.png" alt="">
						</div>
					</div>					
					<div class="content_text">
						<h1>Houses Of Konkan</h1>
						<span>A Chumbak Original, the Tiger Miniature Wall Art represents brilliant re-imaginations <br> of the world around us. It has been created especially for you, printed on 100% acid.</span>
					</div>
					<span class="right_arrow">
						<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
				            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-navigate-up-arrow"></use>
				        </svg>
					</span>					
				</div>
			</div>
		</div>
		<script src="<?php echo $js_script_path; ?>"></script>
	</body>
</html>