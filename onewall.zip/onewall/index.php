<?php
	require_once("./common/inc_global.php");
	require_once(CONFIG_PATH . 'curl.php');
	require_once(CONFIG_PATH . 'functions.php');

	// $css_script_path 	= fnGetScriptFileName(CSS_PATH.'home.css');
	// $js_script_path 	= fnGetScriptFileName(JS_PATH.'home.js');
	$css_script_path 	= CSS_PATH.'home.css';
	$js_script_path 	= JS_PATH.'home.js';
	$icon_path			= ICON_PATH;
	$img_path			= IMG_PATH;
?>
<!DOCTYPE HTML>
<html lang="en">
	<head>
		<title><?php echo COMPANY_NAME ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="<?php echo $css_script_path; ?>" rel="stylesheet" type="text/css">
	</head>
	<body>
		<?php require_once $inc_path.'inc_header.php'; ?>

		<div class="hm_section _banner">
			<div class="wrapper">
				<div class="hm_top">
					<div class="hmt_text">
						<div class="hmt_table _leftbox">
							<div class="hmt_cell">
								<div class="__inner">
									<h2 class="chead">say hello to <br> everchanging art</h2>
									<p class="cbody">flirt with art, move on when <br> you're bored. #youngart</p>
								</div>
								<div class="__inner">
									<h2 class="chead">what colour floats <br> your boat?</h2>
									<p class="cbody">frames in 5 colours <br> turmeric | peacock | post box | ink | snow</p>
								</div>
							</div>
						</div>
					</div>
					<div class="hmt_img">
						<div class="product_section">
							<img class="__frame" src="<?php echo $img_path; ?>frame1.png" alt="">
							<img class="__image" src="<?php echo $img_path; ?>temple.png" alt="">
						</div>
						<div class="__dots">
							<span id="cframe_img1" class="cframe_dot _col1"></span>
							<span id="cframe_img2" class="cframe_dot _col2"></span>
							<span id="cframe_img3" class="cframe_dot _col3"></span>
							<span id="cframe_img4" class="cframe_dot _col4"></span>
							<span id="cframe_img5" class="cframe_dot _col5"></span>
							<span id="cframe_img6" class="cframe_dot _col6"></span>
						</div>
					</div>
					<div class="hmt_text">
						<div class="hmt_table _rightbox">
							<div class="hmt_cell _rightcell">
								<div class="__inner">
									<h2 class="chead">pick something <br> you fancy!</h2>
									<span class="cbody">new day new art, <br> there's never a dull day here. <br> now keep changing your art <br> with a simple click-magnet lock!</span>
								</div>
							</div>
						</div>
					</div>
					<div class="hmt_nav">
						<span class="__top_arrow">
							<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
					            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-navigate-up-arrow"></use>
					        </svg>
						</span>
						<div class="rslider_container">
							<div class="__rslider">
								<img class="rsliderimage" src="<?php echo $img_path; ?>abstract.jpg" alt="">
							</div>
							<div class="__rslider">
								<img class="rsliderimage" src="<?php echo $img_path; ?>cat.jpg" alt="">
							</div>
							<div class="__rslider">
								<img class="rsliderimage" src="<?php echo $img_path; ?>girl.jpeg" alt="">
							</div>
							<div class="__rslider">
								<img class="rsliderimage" src="<?php echo $img_path; ?>mario.png" alt="">
							</div>
							<div class="__rslider">
								<img class="rsliderimage" src="<?php echo $img_path; ?>cat.jpg" alt="">
							</div>
						</div>
						<span class="__bot_arrow">
							<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
					            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-arrow-down-sign-to-navigate"></use>
					        </svg>
						</span>
					</div>
				</div>
			</div>
		</div>

		<div class="hm_section _producttype">
			<div class="pt_lefttable">
				<div class="pt_leftcell">
					<div class="__image">
						<img src="<?php echo $img_path; ?>leftframe.png" alt="">
					</div>
					<div class="__pttext">
						<h1>Art Frames</h1>
						<span>Ever-Changing Art</span>
					</div>
					<div class="__ptbutton">
						<input type="button" class="viewall" name="viewall" value="View All" id="framesubmit"/>
					</div>
				</div>
			</div>
			<div class="pt_righttable">
				<div class="pt_rightcell">
					<div class="__image">
						<img src="<?php echo $img_path; ?>lamp.png" alt="">
					</div>
					<div class="__pttext">
						<h1>LampShades</h1>
						<span>Light Up Your Space</span>
					</div>
					<div class="__ptbutton">
						<input type="button" class="viewall" name="viewall" value="View All" id="lampsubmit"/>
					</div>
				</div>
			</div>
		</div>

		<div class="hm_section _storyslider">
			<div class="wrapper">
				<div class="story_container">
					<h2 class="section_header">#onewallstories</h2>
					<div class="storyfrm_list">
						<div class="storyfrm_section">
							<div class="__inner">
								<img class="__frame" src="<?php echo $img_path; ?>frame1.png" alt="">
								<img class="__image" src="<?php echo $img_path; ?>Rajasthan1.png" alt="">
							</div>
						</div>
						<div class="storyfrm_section">
							<div class="__inner">
								<img class="__frame" src="<?php echo $img_path; ?>frame1.png" alt="">
								<img class="__image" src="<?php echo $img_path; ?>Rajasthan1.png" alt="">
							</div>
						</div>
						<div class="storyfrm_section">
							<div class="__inner">
								<img class="__frame" src="<?php echo $img_path; ?>frame1.png" alt="">
								<img class="__image" src="<?php echo $img_path; ?>Rajasthan1.png" alt="">
							</div>
						</div>
					</div>
					<div class="__stext">
						<h1>Houses Of Konkan</h1>
						<p>A Chumbak Original, the Tiger Miniature Wall Art represents brilliant re-imaginations</p>
						<p>of the world around us. It has been created especially for you, printed on 100% acid.</p>						
					</div>
					<span class="__right_arrow">
						<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
				            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-arrow-point-to-right"></use>
				        </svg>
					</span>
					<span class="__left_arrow">
						<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
				            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-arrowhead-thin-outline-to-the-left"></use>
				        </svg>
					</span>
				</div>
			</div>
		</div>

		<div class="hm_section _detailsbox">
				<div class="details_container">
					<h1>What Is #YoungArt?</h1>
					<p>Art that is a visual delight</p>
					<p>Art that is accessible</p>
					<p>Art that is Everchanging&#8482;</p>
					<p>Art that is simple, yet Meaningful</p>
					<div class="__detailsbtn">
						<input type="button" class="viewall" name="readall" value="Read All" id="readAll"/>
					</div>
				</div>
		</div>

		<?php require_once $inc_path.'inc_footer.php'; ?>
		<script src="<?php echo $js_script_path; ?>"></script>
	</body>
</html>