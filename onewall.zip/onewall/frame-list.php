<?php
	require_once("./common/inc_global.php");
	require_once(CONFIG_PATH . 'curl.php');
	require_once(CONFIG_PATH . 'functions.php');

	// $css_script_path 	= fnGetScriptFileName(CSS_PATH.'home.css');
	// $js_script_path 	= fnGetScriptFileName(JS_PATH.'home.js');
	$css_script_path 	= CSS_PATH.'frame-list.css';
	$js_script_path 	= JS_PATH.'frame_list.js';
	$icon_path			= ICON_PATH;
	$img_path			= IMG_PATH;
?>
<!DOCTYPE HTML>
<html lang="en">
	<head>
		<title>OneWall</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="<?php echo $css_script_path; ?>" rel="stylesheet" type="text/css">
	</head>
	<body class="frame_list">
		<?php require_once $inc_path.'inc_header.php'; ?>
		<div class="fl-section">
			<div class="wrapper">
				<div class="fl_container">
					<div class="frame_box">
						<div class="frame_card">
							<div class="frame_poster">
								<img class="posterimg" src="<?php echo $img_path; ?>leaningtower.png" alt="">
							</div>
							<a class="_carddetails" href="" target="_blank">
								<p class="frame_name">Leaning Tower Pop Print</p>
								<p class="frame_type">Framed Art Print</p>
								<p class="frame_price">Rs.700</p>
							</a>
						</div>
					</div>
					<div class="frame_box">
						<div class="frame_card">
							<div class="frame_poster">
								<img class="posterimg" src="<?php echo $img_path; ?>leaningtower.png" alt="">
							</div>
							<a href="" target="_blank">
								<p class="frame_name">Leaning Tower Pop Print</p>
								<p class="frame_type">Framed Art Print</p>
								<p class="frame_price">Rs.700</p>
							</a>
						</div>
					</div>
					<div class="frame_box">
						<div class="frame_card">
							<div class="frame_poster">
								<img class="posterimg" src="<?php echo $img_path; ?>leaningtower.png" alt="">
							</div>
							<a href="" target="_blank">
								<span class="frame_name">Leaning Tower Pop Print</span>
								<span class="frame_type">Framed Art Print</span>
								<span class="frame_price">Rs.700</span>
							</a>
						</div>
					</div>
					<div class="frame_box">
						<div class="frame_card medium">
							<div class="frame_poster medium">
								<img class="posterimg" src="<?php echo $img_path; ?>girlpower.png" alt="">
							</div>
							<a href="" target="_blank">
								<span class="frame_name">Leaning Tower Pop Print</span>
								<span class="frame_type">Framed Art Print</span>
								<span class="frame_price">Rs.700</span>
							</a>
						</div>
					</div>
					<div class="frame_box">
						<div class="frame_card medium">
							<div class="frame_poster medium">
								<img class="posterimg" src="<?php echo $img_path; ?>girlpower.png" alt="">
							</div>
							<a href="" target="_blank">
								<span class="frame_name">Leaning Tower Pop Print</span>
								<span class="frame_type">Framed Art Print</span>
								<span class="frame_price">Rs.700</span>
							</a>
						</div>
					</div>
					<div class="frame_box">
						<div class="frame_card medium">
							<div class="frame_poster medium">
								<img class="posterimg" src="<?php echo $img_path; ?>girlpower.png" alt="">
							</div>
							<a href="" target="_blank">
								<span class="frame_name">Leaning Tower Pop Print</span>
								<span class="frame_type">Framed Art Print</span>
								<span class="frame_price">Rs.700</span>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php require_once $inc_path.'inc_footer.php'; ?>
		<script src="<?php echo $js_script_path; ?>"></script>
	</body>
</html>