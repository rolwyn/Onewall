<?php
	require_once("./common/inc_global.php");
	require_once(CONFIG_PATH . 'curl.php');
	require_once(CONFIG_PATH . 'functions.php');

	// $css_script_path 	= fnGetScriptFileName(CSS_PATH.'home.css');
	// $js_script_path 	= fnGetScriptFileName(JS_PATH.'home.js');
	$css_script_path 	= CSS_PATH.'frame-list.css';
	$js_script_path 	= JS_PATH.'frame_list.js';
	$icon_path			= ICON_PATH;
	$img_path			= IMG_PATH;
?>
<!DOCTYPE HTML>
<html lang="en">
	<head>
		<title>OneWall</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="<?php echo $css_script_path; ?>" rel="stylesheet" type="text/css">
	</head>
	<body class="frame_list">
		<?php require_once $inc_path.'inc_header.php'; ?>
		<div class="fl-section">
			<div class="wrapper">
				<div class="fl_container">
					<div class="frame_box">
						<div class="frame_card">
							<span class="__lightbulb">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
						            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-light-bulb-outline"></use>
						        </svg>
							</span>
							<a href="" target="_blank">
								<div class="__frmposter">
									<div class="postertable">
										<div class="postercell">
											<img class="_posterimg" src="<?php echo $img_path; ?>leaningtower.png" alt="">
										</div>
									</div>
								</div>
								<div class="__frmdetails">
									<p class="frame_name">Leaning Tower Pop Print</p>
									<p class="frame_type">Framed Art Print</p>
									<p class="frame_price">Rs.700</p>
								</div>
							</a>
						</div>
					</div>
					<div class="frame_box">
						<div class="frame_card">
							<span class="__lightbulb">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
						            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-light-bulb-outline"></use>
						        </svg>
							</span>
							<a href="" target="_blank">
								<div class="__frmposter">
									<div class="postertable">
										<div class="postercell">
											<img class="_posterimg" src="<?php echo $img_path; ?>girlpower.png" alt="">
										</div>
									</div>
								</div>
								<div class="__frmdetails">
									<p class="frame_name">Leaning Tower Pop Print</p>
									<p class="frame_type">Framed Art Print</p>
									<p class="frame_price">Rs.700</p>
								</div>
							</a>
						</div>
					</div>
					<div class="frame_box">
						<div class="frame_card">
							<span class="__lightbulb">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
						            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-light-bulb-outline"></use>
						        </svg>
							</span>
							<a href="" target="_blank">			
								<div class="__frmposter">
									<div class="postertable">
										<div class="postercell">
											<img class="_posterimg" src="<?php echo $img_path; ?>leaningtower.png" alt="">
										</div>
									</div>
								</div>
								<div class="__frmdetails">
									<p class="frame_name">Leaning Tower Pop Print</p>
									<p class="frame_type">Framed Art Print</p>
									<p class="frame_price">Rs.700</p>
								</div>
							</a>
						</div>
					</div>
					<div class="frame_box">
						<div class="frame_card">
							<span class="__lightbulb">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
						            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-light-bulb-outline"></use>
						        </svg>
							</span>
							<a href="" target="_blank">
								<div class="__frmposter">
									<div class="postertable">
										<div class="postercell">
											<img class="_posterimg" src="<?php echo $img_path; ?>girlpower.png" alt="">
										</div>
									</div>
								</div>
								<div class="__frmdetails">
									<p class="frame_name">Leaning Tower Pop Print</p>
									<p class="frame_type">Framed Art Print</p>
									<p class="frame_price">Rs.700</p>
								</div>
							</a>
						</div>
					</div>
					<div class="frame_box">
						<div class="frame_card">
							<span class="__lightbulb">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
					            	<use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-light-bulb-outline"></use>
					        	</svg>
							</span>								
							<a href="" target="_blank">
								<div class="__frmposter">
									<div class="postertable">
										<div class="postercell">
											<img class="_posterimg" src="<?php echo $img_path; ?>leaningtower.png" alt="">
										</div>
									</div>
								</div>
								<div class="__frmdetails">
									<p class="frame_name">Leaning Tower Pop Print</p>
									<p class="frame_type">Framed Art Print</p>
									<p class="frame_price">Rs.700</p>
								</div>
							</a>
						</div>
					</div>
					<div class="frame_box">
						<div class="frame_card">
							<span class="__lightbulb">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
						            <use xlink:href="<?php echo $icon_path; ?>common-icons.svg#icon-light-bulb-outline"></use>
						        </svg>
							</span>					
							<a href="" target="_blank">
								<div class="__frmposter">
									<div class="postertable">
										<div class="postercell">
											<img class="_posterimg" src="<?php echo $img_path; ?>girlpower.png" alt="">
										</div>
									</div>
								</div>
								<div class="__frmdetails">
									<p class="frame_name">Leaning Tower Pop Print</p>
									<p class="frame_type">Framed Art Print</p>
									<p class="frame_price">Rs.700</p>
								</div>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php require_once $inc_path.'inc_footer.php'; ?>
		<script src="<?php echo $js_script_path; ?>"></script>
	</body>
</html>