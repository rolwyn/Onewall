<?php 

	$response_array = [

		"GEN-101"	=>	[
							"DisplayMessage"	=>	"Parameters missing, please make sure you have correct access or contact support"
						],

		"GEN-102"	=>	[
							"DisplayMessage"	=>	'Cache Cleared'
						],

		"GEN-103"	=>	[
							'System-Error'		=>	'Cache failure',
							'DisplayMessage'	=>	'Could not clear cache, please try again'
						],

		"GEN-1007"	=>	[
							"DisplayMessage"	=>	"New record created successfully with property mapped to tenant & bed."
						],

		"GEN-1008"	=>	[
							"DisplayMessage"	=>	"New record created successfully"
						],

		"GEN-1009"	=>	[
							"System-Error"		=>	"General Sql else errors!",
							"DisplayMessage"	=>	"Error"
						],

		"GEN-1010"	=>	[
							"DisplayMessage"	=>	"Tenant added to Mongo & "
						],

		"GEN-1011"	=>	[
							"System-Error"		=>	"General Else errors!",
							"DisplayMessage"	=>	"Tenant NOT added to Mongo"
						],

		"GEN-1012"	=>	[
							"DisplayMessage"	=>	"Mongo Update success & "
						],

		"GEN-1013"	=>	[
							"System-Error"		=>	"General Else errors!",
							"DisplayMessage"	=>	"Mongo Update FAILED"
						],

		"GEN-1014"	=>	[
							"DisplayMessage"	=>	"Updated"
						],

		"GEN-1015"	=>	[
							"DisplayMessage"	=>	"Bed Vacated"
						],

		"GEN-1016"	=>	[
							"System-Error"		=>	"Sql fail, entered else",
							"DisplayMessage"	=>	"Bed failed to vacate"
						],

		"GEN-1017"	=>	[
							"System-Error"		=> "Sql fail, entered else",
							"DisplayMessage"	=> "Mongo updated, failed to update SQL, Bed not released"
						],

		"GEN-1018"	=>	[
							"System-Error"		=>	"Mongo fail",
							"DisplayMessage"	=>	"Failed"
						],

		"GEN-1019"	=>	[
							"DisplayMessage"	=>	"Data updated, pre-booking received! Bed status unchanegd."
						],

		"GEN-1020"	=>	[
							"System-Error"		=>	"",
							"DisplayMessage"	=>	"Bed already reserved"
						],

		"GEN-1021"	=>	[
							"System-Error"		=>	"",
							"DisplayMessage"	=>	"Cannot start new tenure before the previous ends!"
						],

		"GEN-1022"	=>	[
							"DisplayMessage"	=>	"Reserved Bed for the next tenure!"
						],

		"GEN-1023"	=>	[
							"System-Error"		=>	"tbl_beds update failed",
							"DisplayMessage"	=>	"Sorry! not able to reserve bed for next tenure. Please check details else contact admin!"
						],

		"GEN-1024"	=>	[
							'System-Error'		=>	'tbl_beds update failed',
							'DisplayMessage'	=>	'Could not update beds_status to pre-booking'
						],

		"GEN-1025"	=>	[
							'System-Error'		=>	'Failed to stack for refunds',
							'DisplayMessage'	=>	'Bed Vacated, but not stacked for refunds'
						],

		"GEN-1026"	=>	[
							'System-Error'		=> 	'',
							'DisplayMessage'	=>	'Damage punched but failed to generate Invoice'
						],

		"GEN-1027"	=>	[
							'System-Error'		=>	'Curl fail',
							'DisplayMessage'	=>	'Email not sent'
						],

		"GEN-1028"	=>	[
							'DisplayMessage'	=>	'Email Sent Successfully'
						],

		"GEN-1029"	=>	[
							'System-Error'		=>	'Curl fail',
							'DisplayMessage'	=>	'SMS not sent'
						],

		"GEN-1030"	=>	[
							'DisplayMessage'	=>	'SMS sent successfully'
						],

		"GEN-1031"	=>	[
							'System-Error'		=>	'',
							'DisplayMessage'	=>	'No empty inventory matching your search criteria'
						],

		"GEN-1032"	=>	[
							'System-Error'		=>	'',
							'DisplayMessage'	=>	'The record with same mobile number already exists'
						],

		"GEN-1033"	=>	[
							'System-Error'		=>	'',
							'DisplayMessage'	=>	'Image upload failed'
						],

		"GEN-1034"	=>	[
							'System-Error'		=>	'',
							'DisplayMessage'	=>	'You have already rated the agent for this enquiry'
						],

		"GEN-1035"	=>	[
							'System-Error'		=>	'',
							'DisplayMessage'	=>	'The agent has not spoken to this lead, kindly input the correct lead'
						],
		"GEN-1036"	=>	[
							'System-Error'		=>	'',
							'DisplayMessage'	=>	'PDF upload failed'
						],

		"GEN-2000"	=>	[
							"System-Error"		=>	"",
							"DisplayMessage"	=>	"Login Session Expired"
						],

		"GEN-2001"	=>	[
							"System-Error"		=>	"",
							"DisplayMessage"	=>	"The tenant already exists"
						],

		"GEN-2002"	=>	[
							"System-Error"		=>	"",
							"DisplayMessage"	=>	"No data found for tenant"
						],

		"GEN-2003"	=>	[
							"System-Error"		=>	"",
							"DisplayMessage"	=>	"Tenant not associated to any property"
						],

		"GEN-2004"	=>	[
							"System-Error"		=>	"",
							"DisplayMessage"	=>	"Invalid Login Credentials"
						],

		"GEN-2005"	=>	[
							"DisplayMessage"	=>	"Password updated successfully"
						],

		"GEN-2006"	=>	[
							"System-Error"		=>	"",
							"DisplayMessage"	=>	"Sorry, we could not update your password. "
						],

		"GEN-2007"	=>	[
							"System-Error"		=>	"",
							"DisplayMessage"	=>	"Tenant does not exists"
						],

		"GEN-2008"  => 	[
							"DisplayMessage"	=>	"User Successfully logged out."
						],

		"GEN-2009"	=>	[
							"DisplayMessage"	=>	"Successfully logged out of all devices."
						],

		"GEN-2010"	=>	[
							"System-Error"		=>	"",
							"DisplayMessage"	=>	"No active sessions."
						],

		"GEN-2011"	=>	[
							"System-Error"		=>	"",
							"DisplayMessage"	=>	"No Records Found!"
						],

		"GEN-2012"	=>	[
							"DisplayMessage"	=>	"Invoice updated successfully"
						],

		"GEN-2013"	=>	[
							"DisplayMessage"	=>	"Generated"
						],

		"GEN-2014"	=>	[
							'System-Error'		=>	'End Dates Not Same',
							'DisplayMessage'	=>	'Please update the tenant profile correctly'
						],

		"GEN-2015"	=>	[
							'System-Error'		=>	'',
							'DisplayMessage'	=>	'Please delete all future mappings to proceed'
						],

		"GEN-2016"	=>	[
							'System-Error'		=>	'',
							'DisplayMessage'	=>	'Only Single Login Allowed, logout of other devices.'
						],

		"GEN-2017"	=>	[
							'System-Error'		=>	'',
							'DisplayMessage'	=>	'Date Range should be in the same month'
						],

		"GEN-3001"	=>	[
							"DisplayMessage"	=>	"Hey! Thank you for your verification with us!"
						],

		"GEN-3002"	=>	[
							"System-Error"		=>	"Wrong OTP!",
							"DisplayMessage"	=>	"Hey! It is an Invalid OTP! Please try again."
						],

		"GEN-3003"	=>	[
							"System-Error"		=>	"OTP-Expiry!",
							"DisplayMessage"	=>	"Hey! Your OTP has expired, please regenerate!"
						],

		"GEN-3004"	=>	[
							"System-Error"		=>	"Maybe a Hack!",
							"DisplayMessage"	=>	"Please Generate an OTP first!"
						],

		"GEN-3005"	=>	[
							"System-Error"		=>	"Max Tries Reached!",
							"DisplayMessage"	=>	"Hey! You have exceeded the maximum number of OTP requests. Please try again in another hour!"
						],

		"GEN-3006"	=>	[
							"DisplayMessage"	=>	"Hey! Thanks for generating an OTP! You should receive a SMS with the same soon."
						],

		"GEN-3007"	=>	[
							"DisplayMessage"	=>	"Failed generating Otp. Please try again"
						],

		"GEN-3008"	=>	[
							'System-Error'		=>	'',
							'DisplayMessage'	=>	'No registered user with this mobile number'
						],

		"GEN-3009"	=>	[
							'System-Error'		=>	'',
							'DisplayMessage'	=>	'Please enter the registered mobile number'
						],

		"GEN-4001"	=>	[
							"DisplayMessage"	=>	"Please provide the type of coupon"
						],

		"GEN-4002"	=>	[
							"DisplayMessage"	=>	"Coupon with same amount and reason already exists"
						],

		"GEN-4003"	=>	[
							"DisplayMessage"	=>	"Coupon generated successfully"
						],

		"GEN-4004"	=>	[
							"DisplayMessage"	=>	"Sorry! This code is not valid against your id."
						],

		"GEN-4005"	=>	[
							"DisplayMessage"	=>	"Sorry, this offer ​is either invalid or expired."
						],

		"GEN-4006"	=>	[
							"DisplayMessage"	=>	"Coupon already exists"
						],

		"GEN-4007"	=>	[
							"DisplayMessage"	=>	"Sorry you have already used this offer"
						],

		"GEN-4008"	=>	[	
							"System-Error"		=>	"Could not set to cache",
							"DisplayMessage"	=>	"Failed to generate coupon"
						],

		"GEN-4009"	=>	[
							"DisplayMessage"	=>	"Sorry! This coupon is not valid in your city."
						],

		"GEN-4010"	=>	[
							"DisplayMessage"	=>	"Sorry! This coupon is not valid in your area."
						],

		"GEN-4011"	=>	[
							"DisplayMessage"	=>	"Sorry! This coupon is not valid for your property."
						],

		"GEN-4012"	=>	[
							'System-Error'		=>	'Could not delte coupon from cache',
							'DisplayMessage'	=>	'Could not deactivate previous coupon.'
						],

		"GEN-5001"	=>	[
							"DisplayMessage"	=>	"Could Not create login for user"
						],

		"GEN-5002"	=>	[
							"DisplayMessage"	=>	"Owner added Successfully"
						],

		"GEN-5003"	=>	[
							"DisplayMessage"	=>	"No tenures mapped to this property"
						],

		"GEN-5004"	=>	[
							"DisplayMessage"	=>	"This tenure does not exists"
						],

		"GEN-5005"	=>	[
							"DisplayMessage"	=>	"Could Not update login for user"
						],

		"GEN-5006"	=>	[
							"DisplayMessage"	=>	"The property is already mapped to a different owner"
						],

		"GEN-5007"	=>	[
							"DisplayMessage"	=>	"Owner already exists"
						],

		"GEN-5008"	=>	[
							"DisplayMessage"	=>	"Damage punched,Could not update Invoice. Contact back-end team."
						],

		"GEN-5009"	=>	[
							"System-Error"		=>	"",
							"DisplayMessage"	=>	"No owner mapped to this property"
						],

		"GEN-6001"	=>	[
							"System-Error"		=>	"Failed to add to mongo",
							"DisplayMessage"	=>	"Could not punch invoice, please try again."
						],

		"GEN-6002"	=>	[
							"System-Error"		=>	"Failed to delete from pending invoices",
							"DisplayMessage"	=>	"Invoice paid but not deleted from pending"
						],

		"GEN-6003"	=>	[
							"DisplayMessage"	=>	"Invoice Punched Successfully"
						],

		"GEN-6004"	=>	[
							"System-Error"		=>	"",
							"DisplayMessage"	=>	"Failed to delete Invoices"
						],

		"GEN-7001"	=>	[
							"DisplayMessage"	=>	'Lender added/updated successfully'
						],

		"GEN-7002"	=>	[
							'System-Error'		=>	'',
							'DisplayMessage'	=>	'No Lenders matching the search criteria'
						],

		"GEN-7003"	=>	[
							'System-Error'		=>	'',
							'DisplayMessage'	=>	'Failed to generate invoice, contact admin'
						],

		"GEN-7004"	=>	[
							'System-Error'		=>	'',
							'DisplayMessage'	=>	'File upload karna kahe bhul gaye?!'
						],

		"GEN-8001"	=>	[
							'System-Error'		=>	'',
							'DisplayMessage'	=>	'Hey, you have already subscribed to our newsletter! Keep checking your inbox for new stuff!'
						],

		"GEN-8002"	=>	[
							'DisplayMessage'	=>	'Thanks for subscribing with us, keep checking your inbox for best offers!'
						],

		"GEN-8003"	=>	[
							'System-Error'		=>	'',
							'DisplayMessage'	=>	"We're sorry to see you go! :("
						],

		"GEN-8004"	=>	[
							'System-Error'		=>	'Mongo update failed',
							'DisplayMessage'	=>	"Couldn't unsubscribe you, please try again!"
						],

		"GEN-8005"	=>	[
							'System-Error'		=>	'',
							'DisplayMessage'	=>	'Tenant Not subscribed to newsletter'
						]

	];

 ?>