<?php 
	
	/*===============================================
	=            Define global variables            =
	===============================================*/
	
	// GETTING THE CONFIGPATH
	if(!defined('CONFIG_PATH')) {
		define('CONFIG_PATH', __DIR__ . '/');
	}

	if (!defined('DB_NAME')) {
		define('DB_NAME', 'getsetho_scholnll_getsethome');
	}

	if (!defined('DB_HOST')) {
		define('DB_HOST', 'onewall.local:3306');
	}

	if (!defined('DB_USER')) {
		define('DB_USER', 'root');
	}
	
	if (!defined('DB_PASS')) {
		define('DB_PASS', '');
	}

	if(!defined('MONGO_DB_USER')) {
		define('MONGO_DB_USER', 'gshlocalusr');
	}

	if(!defined('MONGO_DB_PASS')) {
		define('MONGO_DB_PASS', 'flipmongousr1#');
	}

	if(!defined('PROTO')) {
		define('PROTO', "http://");
	}

	if (!defined("API_URL")) {
		// define('API_URL', "https://www.getsethome.info/api/");
		define('API_URL', "onewall.local/api/");
	}

	// if (!defined('IMG_URL')) {
	// 	define('IMG_URL', "//" . $_SERVER['HTTP_HOST'] . "/admin/property/img");
	// }


	// if (!defined('MISC_JS')) {
	// 	define('MISC_JS', "/admin/common/js/misc.js");
	// }


	// if (!defined('KEEP_JS')) {
	// 	define('KEEP_JS', "/admin/common/js/keep.js");
	// }

	// if (!defined('MISC_CSS')) {
	// 	define('MISC_CSS', "/admin/common/css/misc.css");
	// }

	// if (!defined('BUSY_IMG_URL')) {
	// 	define('BUSY_IMG_URL', "/admin/common/img/preloader_gif.gif");
	// }

	if (!defined("REDIS_HOST")) {
		define('REDIS_HOST', "127.0.0.1");
	}

	if (!defined("REDIS_PORT")) {
		define('REDIS_PORT', "6379");
	}

	if (!defined("REDIS_TTL")) {
		define('REDIS_TTL', "3600 * 24 * 15");
	}

	// if (!defined("PAY_URL")) {
	// 	define('PAY_URL', "https://www.instamojo.com/getsethome/property-b7faa/");
	// }

	// if(!defined("PAY_REDIRECT_URL")) {
	// 	define("PAY_REDIRECT_URL", "http://" . $_SERVER['HTTP_HOST'] . "/api?cmd=POSTPAYMENT");
	// }

	// if(!defined("SERVICE_CHARGE")) {
	// 	define("SERVICE_CHARGE", "2");
	// }

	// if(!defined("NETBANKING_CHARGE")) {
	// 	define("NETBANKING_CHARGE", "88.5");
	// }

	// if(!defined("WALLET_CHARGE")) {
	// 	define("WALLET_CHARGE", "2.2");
	// }

	// if (!defined('SERVICE_CHARGE_TEXT')) {
	// 	define('SERVICE_CHARGE_TEXT', 'Internet handling fee');
	// }

	// if(!defined('GSH_COMMISSION')) {
	// 	define('GSH_COMMISSION','15');
	// }

	// if(!defined('GST_PERCENT')) {
	// 	define('GST_PERCENT','18');
	// }

	// if(!defined('TDS_PERCENT')) {
	// 	define('TDS_PERCENT', '10');
	// }

	// if(!defined('INSTAMOJO_COMMISSION')) {
	// 	define('INSTAMOJO_COMMISSION', '1.695');
	// }

	// if(!defined('NETBANKING_COMMISSION')) {
	// 	define('NETBANKING_COMMISSION', '75.8');
	// }

	// if(!defined('WALLET_COMMISSION')) {
	// 	define('WALLET_COMMISSION', '1.865');
	// }

	// if(!defined('DEBIT_COMMISSION')) {
	// 	define('DEBIT_COMMISSION', '1.525');
	// }

	// if(!defined('DEBIT_CHARGES')) {
	// 	define('DEBIT_CHARGES', '1.8');
	// }

	// if (!defined('TAX_TEXT')) {
	// 	define('TAX_TEXT', '+ taxes per transaction');
	// }

	if($_SERVER['HTTP_HOST'] == 'onewall.local') {
		if (!defined('IMAGE_API_TOKEN')) {
			define('IMAGE_API_TOKEN', 'FKeSl2OQHT');
		}

	} else if ($_SERVER['HTTP_HOST'] == 'onewall.info') {
		if (!defined('IMAGE_API_TOKEN')) {
			define('IMAGE_API_TOKEN', 'qGMI90m83c');
		}

	} else if ($_SERVER['HTTP_HOST'] == 'onewall.com') {
		if (!defined('IMAGE_API_TOKEN')) {
			define('IMAGE_API_TOKEN', 'Dg3comwyrp');
		}
	}

	// if(!defined('LENDER_PAY_TIME')) {
	// 	define('LENDER_PAY_TIME', '48');
	// }

	// if(!defined("TOKEN_AMOUNT")) {
	// 	define("TOKEN_AMOUNT", "2000");
	// }

	// if(!defined("ENTIRE_HOUSE_TOKEN")) {
	// 	define("ENTIRE_HOUSE_TOKEN", "5000");
	// }

	// COMMON VARIABLES
	// if (!defined("YOURL_API_KEY")) {
	// 	define('YOURL_API_KEY', "SOMETESTAPIKEY");
	// }

	// if (!defined("YOURL_AUTH_TOKEN")) {
	// 	define('YOURL_AUTH_TOKEN', "SOMETESTAUTHTOKEN");
	// }
	
	// if (!defined("PASS_SALT")) {
	// 	define('PASS_SALT', "Pappu123Pappu");
	// }

	if (!defined('IMG_PATH')) {
		define('IMG_PATH', '//' . $_SERVER['HTTP_HOST'] . '/assets/img/');
	}

	// if (!defined('API_TOKEN')) {
 //        define('API_TOKEN', 'kDMCl9h9iv');
 //    }
		
	if (!defined('CONTACT_EMAIL')) {
		define('CONTACT_EMAIL', 'contact.us@getsethome.com');
	}

    if(!defined("HACKER_TXT")) {
    	define("HACKER_TXT","Woah! You have managed to reach here. But we are smarter than you think. It would be interesting to know you, do send us your resume on jobs@getsethome.com.");
    }

    // if(!defined("MAP_API_KEY")) {
    // 	define("MAP_API_KEY", "AIzaSyD8z34x1T0MsWhZyneXq5ngrftt3LW7SpI");
    // }

	/* ==============================
	=	Require a file for AppCode
	=============================== */

	require_once(__DIR__ . '/global_appcodes.php');
	require_once(__DIR__ . '/global_arrays.php');

	/*=====  End of Define global variables  ======*/

	// hardcode

	ini_set("date.timezone", "Asia/Kolkata");


?>