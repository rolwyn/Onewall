<?php
   //Connecting to Redis server on localhost
   
   // error_reporting(E_ALL);
   // ini_set("display_errors", 1);

   // require_once('variables.php');

   
   // if($_SERVER['HTTP_HOST'] == "getsethome.co.in") {

   require_once(__DIR__ . '/variables.php');

      class clsCache {

         function exists($strKey) {
               $redis = new Redis();
               $redis->connect(REDIS_HOST, REDIS_PORT);
               
               $value = $redis->exists($strKey);
               $redis->close();
               return $value;
         }

         function set($strKey, $objData, $intTimeout = 1296000) {
            $redis = new Redis();
            $redis->connect(REDIS_HOST, REDIS_PORT);
            
            $blnFlag = true;
            if (!$redis->exists($strKey) || $objData != $redis->get($strKey)) {
                $blnFlag = $redis->set($strKey, $objData, $intTimeout);
            }

            $redis->close();
            return $blnFlag;
         }

         function get($strKey) {
            $redis = new Redis();
            $redis->connect(REDIS_HOST, REDIS_PORT);

            $value = $redis->get($strKey);
            $redis->close();
            return $value;
         }

         function delete($strKey) {
            $redis = new Redis();
            $redis->connect(REDIS_HOST, REDIS_PORT);
            $blnFlag = $redis->delete($strKey);
            $redis->close();
            return $blnFlag;
         }

         function getAll() {
            $redis = new Redis();
            $redis->connect(REDIS_HOST, REDIS_PORT);
            $arrList = $redis->keys("*");
            $redis->close();
            return $arrList;
         }
      }

   // } else {

      // class clsCache {

      //    function exists($strKey) {
      //       return false;
      //    }

      //    function set($strKey, $objData, $intTimeout = 0) {
            
      //       return true;
      //    }

      //    function get($strKey) {
            
      //       return false;
      //    }
      // }

   // }
   
   $cache = new clsCache();

?>