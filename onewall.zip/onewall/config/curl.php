<?php 

	require_once(__DIR__ . '/variables.php');

	function fnDoCurl($arrPostData) {

		$apiUrl = ( isset($arrPostData['apiUrl']) && $arrPostData['apiUrl'] != "" ) ? $arrPostData['apiUrl'] : API_URL;
		
		if(isset($arrPostData['method']) && $arrPostData['method'] == "GET") {
			$url = $apiUrl . "?" . fnMakeUrl($arrPostData);

			/* Adding Token to the request */

			$url .= "&token=" . API_TOKEN;
			
			/* END == Adding Token to the request */


			$ch	 	= curl_init($url);
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			
			$data = curl_exec($ch);
			curl_close($ch);

			return $data;


		} else {

			$url 	= $apiUrl;
			$ch	 	= curl_init($url);

			if($ch === false){
				die("Failed curl your URL");
			}

			/* Adding Token to the request */

			$arrPostData['token'] = API_TOKEN;

			/* END == Adding Token to the request */
			
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $arrPostData);
			
			$data = curl_exec($ch);
			curl_close($ch);

			return $data;			
		
		}

	}
?>