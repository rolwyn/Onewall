<?php 

	// error_reporting(0);
	// error_reporting(E_ALL);
	// ini_set("display_errors", 1);

	$blocked_property = ["PRT074"];
		
 ?>