<?php 

	// error_reporting(0);
	// error_reporting(E_ALL);
	// ini_set("display_errors", 1);

	$blocked_property = ["PRT074"];
	
	$arrTokenAmounts = [
		'CAT1000' 	=> '2000',
		'CAT1001'	=> '2000',
		'CAT1002'	=> '5000'
	];
	
	$arrGendersConfic = [
		'FB' 		=> 'Family & Bachelor',
		'OF'		=> 'Only Family',
		'M' 		=> 'Boys',
		'F'			=> 'Girls',
		'female'	=> 'Girls',		//Temp data change in the codes needed.
		'Female'	=> 'Girls',
		'male'		=> 'Boys',
		'Male'		=> 'Boys'
	];
 ?>