<?php
	$GLOBALS['arrMySQLConfig'] = array(
								'host' 		=> 'http://getsethome.com/',
                                'user' 		=> 'root',
                                'password' 	=> '', 
                                'database' 	=> 'test',
                                'port' 		=> '3306'
    );
?>
