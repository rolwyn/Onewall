<?php 

	// error_reporting(0);
	// error_reporting(E_ALL);
	// ini_set("display_errors", 1);

	require_once(__DIR__ .'/variables.php');
	require_once(__DIR__ .'/db.php');

	

 ?>