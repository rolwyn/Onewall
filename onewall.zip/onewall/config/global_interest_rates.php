<?php 

	// error_reporting(0);
	// error_reporting(E_ALL);
	// ini_set("display_errors", 1);

	$arrYear 		= ["21,24"];
	$arrYearandHalf	= ["45,48"];
	$arrTwoyears	= ["67,70"];

 ?>