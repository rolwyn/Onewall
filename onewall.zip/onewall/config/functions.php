<?php

	// error_reporting(0);
	error_reporting(E_ALL);
	// ini_set("display_errors", 1);

	function fnMakeUrl($arrPostData){
		$url = "";

		foreach ($arrPostData as $key => $value) {
			$url .= $key."=".$value."&";
		}

		$request = substr($url, 0, strlen($url)-1);
		return $request;
	}

	function fnGKVPair($data, $delimiter = "|", $equater = "=") {
		$data	=	urldecode($data);
		$arrTokens = array();
		$arrTokens = explode($delimiter, trim($data, "|"));
		for($i = 0; $i < count($arrTokens); $i++) {
			if($arrTokens[$i] != "") {
				$arr = explode($equater, $arrTokens[$i], 2);
				@$arrData[$arr[0]] = $arr[1];
			}
		}

		return $arrData;
	}

	function fnMakeCookieSet($arrPostData){
 		$cookie = "|";

 		foreach ($arrPostData as $key => $value) {
			$cookie .= $key ."=" . $value . "|";
 		}
 		return $cookie;
 	}

	function fnCapitalName($string){
		$string = strtolower($string);
		return ucwords($string);
	}
	
	function fnUrlName($str) {
		$str = strtolower(trim($str));
		$str = preg_replace("/[^a-zA-Z 0-9]+/", "", $str);		// Trim characters except 0-9, a-z and A-Z
		$str = preg_replace("/[ ]+/", "-", $str);				// Replace space by -
		$str = preg_replace("/[-]+/", "-", $str);				// Replace multiple dashes by a single dash
		
		return $str;
	}

	function fnGetLength($str) {
		$min	=	$str % 60;
		$str	=	$str - $min;
		$hr		=	$str / 60;

		$strhr	=	($hr > 1) ? 'hrs' : 'hr' ;
		$strmin	=	($min > 1) ? 'mins' : 'min' ;
		$time	=	"$hr $strhr $min $strmin";

		if($min == 0) {
			$time = "$hr $strhr";
		}
		if($hr == 0) {
			$time = "--";
		}
		if($hr == 0 && $min != 0) {
			$time = "$min $strmin";
		}

		return $time;
	}

	function fnLimitText($text, $limit = 20, $dots = '[...]') {
		$explode = explode(' ', $text);
		$string  = '';
		if(count($explode) <= $limit) {
			$dots = '';
		}
		for($i=0; $i<$limit; $i++) {
			$string .= $explode[$i] . " ";
		}
		if($dots) {
			$string = substr($string, 0, strlen($string));
		}

		return $string . $dots;
	}

	function fnGetIPAddress() {
		$userIPAddress = "";

		if (isset($_SERVER['HTTP_TRUE_CLIENT_IP']) && !empty($_SERVER['HTTP_TRUE_CLIENT_IP'])) {
			$userIPAddress = $_SERVER['HTTP_TRUE_CLIENT_IP'];
		} else if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$userIPAddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$userIPAddress = $_SERVER['REMOTE_ADDR'];
		}

		$userIPAddress = trim(explode(",", $userIPAddress)[0]);

		return $userIPAddress;
	}

	/* make a URL small */
	function fnMakeSmallUrl($url) {
		$format 	=	'json';
		$version 	=	'2.0.1';
		$login 		=	'o_4k87m8gi82';
		$appkey		=	'R_375bdfa1710d40828b7b5e08008c8548';
		//create the URL
		$bitly = 'http://api.bit.ly/shorten?version='.$version.'&longUrl='.urlencode($url).'&login='.$login.'&apiKey='.$appkey.'&format='.$format;
		
		//get the url
		//could also use cURL here
		$response = file_get_contents($bitly);
		
		//parse depending on desired format
		if(strtolower($format) == 'json') {
			$json = @json_decode($response,true);
			return $json['results'][$url]['shortUrl'];
		} else {
			$xml = simplexml_load_string($response);
			return 'http://bit.ly/'.$xml->results->nodeKeyVal->hash;
		}
	}

	function fnGenerateExcel($array, $filename) {
		
		if($filename == "") {
			$filename = "demo";
		}

		header("Content-Disposition: attachment; filename=\"" . $filename . ".xls\"");
		header("Content-Type: application/vnd.ms-excel;");
		header("Pragma: no-cache");
		header("Expires: 0");
		$out = fopen("php://output", 'w');
		foreach ($array as $data) {
		    fputcsv($out, $data,"\t");
		}
		fclose($out);
	}

	function fnGetMonthName($monthNumber) {
		try {

			$monthNum  = intval($monthNumber);
			$dateObj   = DateTime::createFromFormat('m', $monthNum);
			$monthName = $dateObj->format('F');

			return $monthName;

		} catch(Exception $e) {

		}
	}

	function fnSendResponse($response) {

		require_once(__DIR__ . '/Templates/General-Response-Templates.php');
		// global $response_array;

		$data = $response_array[$response['template_id']];

		if($response['type'] == "Success") {

			$result = [
				"status"	=>	$response['blnStatus'],
				"data"		=>	$data,
				"error"		=>	[]
			];
			if(!$response['customData'] == "") {
				$result['data']['customData'] = $response['customData'];
			}
		} else {

			$result = [
				"status"		=>	strtolower($response['blnStatus']),
				"data"			=>	[],
				"error"			=>	$data,
				"error_code"	=>	$response['template_id']
			];
			if(!$response['customData'] == "") {
				$result['error']['customData'] = $response['customData'];
			}
		}


		$result = json_encode($result);
		echo $result;
		exit;
	}

	
	function fnGetPropertyShortAddr($property_id) {
		try {

			global $con;

			$sql = "SELECT
					`tbl_property`.`property_wing`,
					`tbl_property`.`property_flatno`,
					`tbl_property`.`property_building_name`
					FROM `tbl_property`
					WHERE `property_id` = '" . $property_id . "'";

			$short_address = '';
			if($result = $con->query($sql)) {
				while($row = $result->fetch_assoc()) {
					$short_address 	= trim($row['property_wing']) 			!= "" ? trim($row['property_wing']) . "/" 		: ""	;
					$short_address .= trim($row['property_flatno']) 		!= "" ? trim($row['property_flatno']) . ", " 	: ""	;
					$short_address .= trim($row['property_building_name']) 	!= "" ? trim($row['property_building_name'])   	: ""	;
				}
			}

			return $short_address;

		} catch(Exception $e) {

		}
	}


	function fnCheckLoginStatus($params) {
		try {

			global $cache;

			$arrReturn = [
				'blnStatus' => false,
				'session_data' => "" 
			];

			$redis_key = $params['session_id'];
			if($cache->exists($redis_key)) {
				$result = $cache->get($redis_key);
				$arr = json_decode($result, true);

				/* Check if the session is for same tenant */
				if($arr['user_id'] == $params['user_id']) {
					$arrReturn['blnStatus'] = true;
					$arrReturn['session_data'] = $arr;					
				}
			}

			return $arrReturn;

		} catch(Exception $e) {

		}
	}


	function parse($objData) {
	    
	    // Damn pesky carriage returns...
	    $objData = str_replace("\r\n", "\n", $objData);
	    $objData = str_replace("\r", "\n", $objData);

	    // JSON requires new line characters be escaped
	    $objData = str_replace("\n", "\\n", $objData);
	    return $objData;
	}


	function fnGetHash($params) {
		try {

			$len = $params['length'];

			$time = time();
			$chars = $time."abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ".$time;
			$string="";
		
			for ($i=0; $i <$len ; $i++) { 
				
				$string .= $chars{rand(0, strlen($chars)-1)};	
			}

			return $string;

		} catch (Exception $e) {
			echo $e;
		}
	}

	function fnClearCache($arrParams) {
		try {

			global $cache;
			global $con;

			/* Extract city code and area code using the property_id */

			$sql = "SELECT `property_city`,`property_area`
					FROM `tbl_property`
					WHERE `property_id` = '" .$arrParams['property_id']. "'";

			if($result = $con->query($sql)) {
				while ($row = $result->fetch_assoc()) {
					$city_code = $row['property_city'];
					$area_code = $row['property_area'];
				}
			}

			/*///////////////////////////////////////////////////////////
					   Delete a Redis key for Property and City
			////////////////////////////////////////////////////////////*/

			$arrKeys = $cache->getAll();

			foreach ($arrKeys as $key => $value) {

				$regex = "/GETPROPERTYBYCITY_" . $city_code . "*\w+/";			
				if (preg_match($regex, $value)) {
					$cache->delete($value);
				}

				$regex = "/GETPROPERTYBYAREA_" . $area_code . "*\w+/";			
				if (preg_match($regex, $value)) {
					$cache->delete($value);
				}


				$regex = "/GETPROPERTYDETAILS_" . $arrParams['property_id'] . "*\w+/";			
				if (preg_match($regex, $value)) {
					$cache->delete($value);
				}
			}

			return true;

			/*==== END -> Delete a Redis key for Property and City ====*/

		} catch(Exception $e) {

		}
	}

	function fnClearSearchCache() {
		try {
			
			global $cache;

			$cache->delete('GETALLPROPERTIES');
			return true;

		} catch (Exception $e) {
			echo $e;
		}
	}

	function fnSearchTenant() {
		
		global $con;
		global $mongo;
		$mongo->setCollection("coll_tenants");
		$searchBy = strtolower(trim($_REQUEST['searchBy']));
		$searchTxt = trim($_REQUEST['searchTxt']);

		// ///////////////////////
		// SEARCH BEGINS Here ////
		//////////////////////////

		$arrSearch = explode(" ", $searchTxt);

		if($searchBy == "name") {

			$key = "tenants_fName";
			$arr = $mongo->search($key,$arrSearch[0]);

		} else if($searchBy == "mobile") {

			$key = "tenants_mobile";
			$arr = $mongo->search($key,$arrSearch[0]);

		} else if($searchBy == "email") {

			$key = "tenants_email";
			$arr = $mongo->search($key,$arrSearch[0]);

		} else if ($searchBy == "tenant_id") {
			
			$key = "tenants_id";
			$arr = $mongo->search($key,$arrSearch[0]);
		}

		if(count($arrSearch) > 1) {
			$arrTemp = $arr;
			$arr = [];

			foreach ($arrTemp as $key => $value) {
				
				if(stristr($value['tenants_lName'],$arrSearch[1]) !== FALSE) {
					array_push($arr, $value);
				}
			}
		}

		$arr = fnGetTenantStatus($arr);
		
		fnSendResponse([
			'blnStatus'		=> 'true',
			'type'			=> 'Success',
			'customData'	=>	$arr
		]);

	}

	function fnSearchOwner() {
		try {
			
			$storage_mongo = new clsStorage("Mongo");

			$searchBy	= (isset($_REQUEST['searchBy'])		&& strip_tags(urldecode(htmlspecialchars($_REQUEST['searchBy'])))	!= "") ? strip_tags(urldecode(htmlspecialchars($_REQUEST['searchBy'])))		: "" ;
			$searchTxt 	= (isset($_REQUEST['searchTxt'])	&& strip_tags(urldecode(htmlspecialchars($_REQUEST['searchTxt'])))	!= "") ? strip_tags(urldecode(htmlspecialchars($_REQUEST['searchTxt'])))	: "" ;

			$searchTxt = explode(" ", $searchTxt);

			if($searchBy == "name") {
				$key = 'owner_fName';

			} elseif ($searchBy == "mobile") {
				$key = 'owner_mobile';

			} elseif ($searchBy == "id") {
				$key = 'owner_id';

			} elseif ($searchBy == "email") {
				$key = 'owner_email';

			}

			$arr = $storage_mongo->searchRecord('coll_owners',$key,$searchTxt[0]);
			
			if(!empty($arr)) {
				if(count($searchTxt) > 1) {
					$arrTemp = $arr;
					$arr = [];

					foreach ($arrTemp as $key => $value) {
						
						if(stristr($value['owner_lName'],$arrSearch[1]) !== FALSE) {
							array_push($arr, $value);
						}
					}
				}

				fnSendResponse([
					'blnStatus'		=>	'true',
					'type'			=>	'Success',
					'customData'	=>	$arr
				]);

			} else {
				fnSendResponse([
					'blnStatus'		=>	'false',
					'type'			=>	'Error',
					'template_id'	=>	'GEN-2011'
				]);
			}

		} catch (Exception $e) {
			echo $e;
		}
	}

	function fnSearchVendor() {

		$storage_mongo = new clsStorage("Mongo");

		$searchBy = strtolower(trim($_REQUEST['searchBy']));
		$searchTxt = trim($_REQUEST['searchTxt']);

		if($searchBy == "name") {

			$key = "company_name";
			$arr = $storage_mongo->searchRecord('coll_vendors',$key,$searchTxt);

		} else if($searchBy == "mobile") {

			$key = "contact_number";
			$arr =  $storage_mongo->searchRecord('coll_vendors',$key,$searchTxt);

		} else if($searchBy == "email") {

			$key = "contact_email";
			$arr =  $storage_mongo->searchRecord('coll_vendors',$key,$searchTxt);

		} else if ($searchBy == "vendor_id") {
			
			$key = "vendor_id";
			$arr =  $storage_mongo->searchRecord('coll_vendors',$key,$searchTxt);
		}

		if(!empty($arr)) {
			fnSendResponse([
				'blnStatus'		=>	'true',
				'type'			=>	'Success',
				'customData'	=>	$arr
			]);

		} else {
			fnSendResponse([
				'blnStatus'	=>	'false',
				'type'		=>	'Error'
			]);
		}

	}

	function fnGetTenantStatus($arr) {
		try {
			
			$storage_sql = new clsStorage("MySQL");
			$storage_mongo = new clsStorage("Mongo");

			// print_r($arr);
			// exit();

			foreach ($arr as $key => $value) {

				if($value['isTenantBlacklisted'] == 'Y') {
					$arr[$key]['status'] = "Blacklisted";
					continue;
				}
				
				$arrRln = $storage_sql->getRecord("tbl_rln_property_tenant",['tenant_id' => $value['tenants_id'], 'isCurrent' => '1']);

				if(!empty($arrRln)) {

					$arr[$key]['status'] = "Existing Tenant";

				} else if(!empty($storage_sql->getMultipleRecords('tbl_beds',['occupied_by' => $value['tenants_id'], 'beds_status' => '5']))) {

					$arr[$key]['status'] = "Existing Tenant";

				} else if(!empty($storage_sql->getMultipleRecords('tbl_beds',['occupied_by' => $value['tenants_id'], 'beds_status' => '2']))) {

					$arr[$key]['status'] = "New Booking";

				} else if(!empty($storage_sql->getRecord('tbl_rln_property_tenant',['tenant_id' => $value['tenants_id']]))) {

					$arr[$key]['status'] = "Left Tenant";

				} else {

					$arr[$key]['status'] = "Signup";

				}
			}
			
			$arr = fnSortTenant($arr);

			return $arr;

		} catch (Exception $e) {
			echo $e;
		}
	}

	function fnSortTenant($arr) {
		try {
			
			$arrFinal = [];

			foreach ($arr as $key => $value) {
				if($value['status'] == "Existing Tenant") {
					array_push($arrFinal, $value);
				}
			}

			foreach ($arr as $key => $value) {
				if($value['status'] == "Left Tenant") {
					array_push($arrFinal, $value);
				}
			}

			foreach ($arr as $key => $value) {
				if($value['status'] == "New Booking") {
					array_push($arrFinal, $value);
				}
			}

			foreach ($arr as $key => $value) {
				if($value['status'] == "Signup") {
					array_push($arrFinal, $value);
				}
			}

			foreach ($arr as $key => $value) {
				if($value['status'] == "Blacklisted") {
					array_push($arrFinal, $value);
				}
			}

			return $arrFinal;

		} catch (Exception $e) {
			echo $e;
		}
	}

	function fnSearchProperty() {
		try {

			global $con;
			global $cache;
			extract($_REQUEST);

			$redis_key = "GETALLACTIVEPROPERTIES";
			$arrProperty = [];
			
			if($cache->exists($redis_key)) {
				$arrProperty = $cache->get($redis_key);
				$arrProperty = json_decode($arrProperty, true);

			} else {

				$sql = "SELECT `property_id`, `property_city`, `property_address`, `property_sales_date`, `property_release_date`, `property_area`, `property_agreement_date`, `property_gender`, `tbl_property`.`property_size_name`, `tbl_property`.`property_type_name`, `property_category`, `city_name`, `area_name`, `category_name`, `tbl_property_size`.`property_size_name`,`tbl_property_type`.`property_type_name`, `property_type_code`,`property_size_code`
					FROM `tbl_property`
					INNER JOIN `tbl_area` ON `tbl_area`.`area_code` 	= `tbl_property`.`property_area`
					INNER JOIN `tbl_property_type` ON `tbl_property_type`.`property_type_code` 	= `tbl_property`.`property_type_name`
					INNER JOIN `tbl_property_size` ON `tbl_property_size`.`property_size_code` 	= `tbl_property`.`property_size_name`
					INNER JOIN `tbl_property_category` ON `tbl_property_category`.`category_id`	= `tbl_property`.`property_category`
					WHERE `property_isActive` = '1'";

				if($result = $con->query($sql)) {
					while($row = $result->fetch_assoc()) {
						
						$row['property_address'] = fnGetPropertyShortAddr($row['property_id']);
						array_push($arrProperty, $row);
					}

					// Set key to Cache
					if(sizeof($arrProperty) > 0) {
						$cache->set($redis_key, json_encode($arrProperty));
					}
				
				} else {
					fnSendErrorResponse($con->error);
				}

			}

			/*===========================================================
			=            Code to search property in an array            =
			===========================================================*/
			$arrFinal = [];
			$regex = "/".strtolower($property_address).".*/";		
			foreach ($arrProperty as $key => $value) {
				$add = strtolower($value['property_address']);
				// if ($property_city == $value['property_city'] && preg_match($regex, $add)) {
				// 	array_push($arrFinal, $value);
				// }
				if (preg_match($regex, $add)) {
					array_push($arrFinal, $value);
				}
			}

			$arrFinal = json_encode($arrFinal);
			$arrFinal = parse($arrFinal);

			echo $arrFinal;
			
		} catch(Exception $e) {
			echo $e;
		}
	}

	function fnSearchAllProperty() {
		try {
			
			global $con;
			global $cache;
			extract($_REQUEST);

			$redis_key = "GETALLPROPERTIES";
			$arrProperty = [];
			
			if($cache->exists($redis_key)) {
				$arrProperty = $cache->get($redis_key);
				$arrProperty = json_decode($arrProperty, true);

			} else {

				$sql = "SELECT `property_id`, `property_city`, `property_address`, `property_sales_date`, `property_release_date`, `property_area`, `property_agreement_date`,`property_tenure`,`property_isActive`
						FROM `tbl_property`";

				if($result = $con->query($sql)) {
					while($row = $result->fetch_assoc()) {
						
						$row['property_address'] = fnGetPropertyShortAddr($row['property_id']);
						array_push($arrProperty, $row);
					}

					// Set key to Cache
					if(sizeof($arrProperty) > 0) {
						$cache->set($redis_key, json_encode($arrProperty));
					}
				
				} else {
					fnSendErrorResponse($con->error);
				}

			}

			/*===========================================================
			=            Code to search property in an array            =
			===========================================================*/
			$arrFinal = [];
			$regex = "/".strtolower($property_address).".*/";		
			
			foreach ($arrProperty as $key => $value) {
				$add = strtolower($value['property_address']);
				
				if (preg_match($regex, $add)) {

					if(array_search($value['property_id'], array_column($arrFinal, 'property_id')) !== false) {
						$prop_key = array_search($value['property_id'], array_column($arrFinal, 'property_id'));
						
						if(intval($value['property_isActive']) == 1) {
							$arrFinal[$prop_key] = $value;

						} else {
							$curr_tenure 	= explode("T", $value['property_tenure']);
							$stored_tenure	= explode("T", $arrFinal[$prop_key]['property_tenure']);

							if($curr_tenure[1] > $stored_tenure[1]) {
								$arrFinal[$prop_key] = $value;
							}
						}

					} else {
						array_push($arrFinal, $value);

					}
				}
			}

			$arrFinal = json_encode($arrFinal);
			$arrFinal = parse($arrFinal);

			echo $arrFinal;

		} catch (Exception $e) {
			echo $e;
		}
	}

	function fnFormatDate($date){
		try{

			$date 		= strtotime($date);
			$formatDate = date('jS M,  Y', $date); 
			return $formatDate;
			
		} catch(Exception $e){
			echo $e;
		}
	}

	function fnDateDifferents($startDate, $endDate, $what){
		try{

			$startDate 		= $startDate;
			$endDate 		= $endDate;

			$diff = abs(strtotime($endDate) - strtotime($startDate));

			if($what == "Y"){
				$years = floor($diff / (365*60*60*24));
				return $years;
			}
			if($what == "M"){
				$months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
				return $months;
			}
			if($what == "D"){
				$days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
				return $days;
			}

		}catch(Exception $e){
			echo $e;
		}
	}

	function fnCalculateTDS($arr) {
		try {
			
			$amount = $arr['amount'];

			/* The amount given is the paid amout
				Hence makes :

				x-0.1x = the given amount
				(where x = the actual amount)

				Hence x = given amount/0.9
			*/

			$acutal_amount = $amount/0.9;

			$tds = $acutal_amount*TDS/100;

			$arr['tds_amount'] = $tds;
			$arr['original_amount']	= $acutal_amount;

			return $arr;

		} catch (Exception $e) {
			echo $e;
		}
	}



	function fnDateDiff($arrParams) {
		try {

			$start 	= date_create($arrParams['date1']);
			$end 	= date_create($arrParams['date2']);

			$diff 	= date_diff($start, $end);

			if($arrParams['format'] == 'days') {
				return intval($diff->format("%R") . "" . $diff->format("%a"));
			
			} else if($arrParams['format'] == 'months') {
				return intval($diff->format("%R") . "" . $diff->format("%m"));
			
			}


		} catch (Exception $e) {

		}
	}

	function fnGetRoomAmenitiesNames($arrPropertyRooms) {
		try {

			$storage_sql = new clsStorage("MySQL");

			foreach($arrPropertyRooms as $key => $value) {
									
				$room_amenities = $value['room_amenities'];

				if($room_amenities != "") {

					$arrTemp = explode('|', $room_amenities);

					$strAmenities = "|" ;
					foreach ($arrTemp as $key1 => $amenity_code) {

						if($amenity_code != "") {

							/* Call room amenities api */		
							$amenity_name = $storage_sql->getMultipleRecords('tbl_property_rooms_amenities', ['property_rooms_amenities_code' => $amenity_code ])[0]['property_rooms_amenities_name'];
							$strAmenities .= $amenity_code . "=" . $amenity_name . "|";
						}
					}

					/* Add amenity to array */
					$arrPropertyRooms[$key]['room_amenities'] = $strAmenities;

				}
			}

			return $arrPropertyRooms;

		} catch (Exception $e) {
			
		}
	}

	function fnGetServiceNames($arr) {
		try {
			
			$services = $arr[0]['property_service'];
			$storage_sql = new clsStorage("MySQL");

			if($services != "") {

				$arrTemp = explode("|", $services);

				$strServices = "|";

				foreach ($arrTemp as $key => $value) {
					if($value != "") {

						$arrServices = explode("=", $value);

						if(count($arrServices) > 1) {
							
							$strServices .= $value."|";
						} else {

							$service_name = $storage_sql->getRecord("tbl_property_service",["property_service_code" => $value])[0]['property_service_name'];
							$strServices .= $value . "=" . $service_name . "|";
						}
					}
				}
			}

			$arr[0]['property_service'] = $strServices;
			
			return $arr;
		} catch (Exception $e) {
			echo $e;
		}
	}
	

	function fnGeneratePDF($strHtml, $filename){
		try{

			$apikey = '4ee5eb9e-b484-46fa-9f02-77b7f4541421';
			$value 	= $strHtml; // a url starting with http or an HTML string
			$result = file_get_contents("http://api.html2pdfrocket.com/pdf?apikey=" . urlencode($apikey) . "&value=" . urlencode($value));
			header("Content-type:application/pdf");
			header("Content-Disposition:inline;filename='$result");
			header("Pragma: public");
			header("Expires: 0");
			header("Cache-Control: must-revalidate, post-check=0, pre-check=0"); 
			header("Content-Type: application/force-download");
			header("Content-Type: application/octet-stream");
			header("Content-Type: application/download");
			header("Content-Disposition: attachment;filename=$filename.pdf ");
			header("Content-Transfer-Encoding: binary ");
			return $result;
			
		} catch (Exception $e) {
			echo $e;
		}
	}

	function fnGetNewId($tbl_name,$prefix,$field) {

		$storage_mongo = new clsStorage("Mongo");

		$arrData = $storage_mongo->getAll($tbl_name);
		$max = 1000;

		foreach ($arrData as $key => $value) {
			
			$arrSplit = explode($prefix, $value[$field]);

			if(intval($arrSplit[1]) > $max)
				$max = intval($arrSplit[1]);
		}

		$max += 1;

		return $prefix . $max;
	}

	function fnGetEndTime($end_date) {
		try {
			
			$current_date 	= strtotime(date('Y-m-d H:i:s'));
			$end_date		= date('Y-m-d 23:59:59',strtotime($end_date));

			$end_date		= strtotime($end_date);
			$diff			= $end_date - $current_date;

			return $diff;

		} catch (Exception $e) {
			echo $e;
		}
	}

	function fnGetDistance($params) {
		try {
			
			$url = "https://maps.googleapis.com/maps/api/distancematrix/json?units=metric&key=".MAP_API_KEY."&origins=".$params['origin']."&destinations=".$params['destination'];

			$url = substr($url, 0, strlen($url)-1);

			$ch = curl_init($url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$curl_data = curl_exec($ch);
			curl_close($ch);

			$curl_data = json_decode($curl_data,true);
			return $curl_data;

		} catch (Exception $e) {
			echo $e;
		}
	}

	function fnGetallBlogs() {
		try {
			
			$storage_mongo = new clsStorage("Mongo");

			$arrData = $storage_mongo->getAll('coll_seo_articles');

			foreach ($arrData as $key => $value) {
				$arrData[$key]['blog_text_field'] = nl2br(strip_tags($value['blog_text_field']));

				$url = $_SERVER['DOCUMENT_ROOT'] . "/assets/img/seo-article/" . $value['seo_id'] . "/"; 

				if(file_exists($url)) {
					$files = new RecursiveIteratorIterator (

							new RecursiveDirectoryIterator($url)
					);
					$IMG_URL = "/assets/img/seo-article/".$value['seo_id'].'/';
					
					foreach ($files as $filename) {
						if($filename == "." || $filename == ".." || $filename == ".DS_Store") {
							//ignore these files
						} else {

							$file_name = explode(".", $filename);
							if($file_name[1] != '') {
								$temp_name = explode("/", $file_name[0]);
								$img_name = end($temp_name).'.'.end($file_name);
								$arrData[$key]['img_url'] = $IMG_URL . $img_name;
							}
						}
					}
				}
			}

			if(!empty($arrData)) {
				fnSendResponse([
					'blnStatus'		=>	'true',
					'type'			=>	'Success',
					'customData'	=>	$arrData
				]);

			} else {
				fnSendResponse([
					'blnStatus'		=>	'false',
					'type'			=>	'Error',
					'template_id'	=>	'GEN-2011'
				]);
			}

		} catch (Exception $e) {
			echo $e;
		}
	}

	function fnGetScriptFileName($base_name) {
		try {
			// $base_name = '/assets/css/home.css';
			$arrPath = explode("/", $base_name);
			$arrPath = array_filter($arrPath);

			$actual_path = '/'.$arrPath[1].'/'.$arrPath[2].'/';	

			$arrFileName = explode(".", $arrPath[3]);				
			$arrFileName = array_filter($arrFileName);

			$new_url = $_SERVER['DOCUMENT_ROOT'] .'/'. $arrPath[1] .'/'. $arrPath[2] .'/';			

			if(file_exists($new_url)) {
				$files = new RecursiveIteratorIterator (
					new RecursiveDirectoryIterator($new_url)
				);
				

				foreach ($files as $filename) {
					if($filename == $new_url . "." || $filename == $new_url . ".." || $filename == $new_url . ".DS_Store") {
						//ignore these files
					} else {
						$arrExplodeFiles = explode(".", $filename);
						$arrExplodeFiles = array_filter($arrExplodeFiles);

						if($arrExplodeFiles[0] == $new_url.$arrFileName[0]) {
							$actual_path .= ($arrFileName[0].'.'.$arrExplodeFiles[1].'.'.$arrExplodeFiles[2]);
							break;
						}
					}
				}
			}

			return $actual_path;

		} catch (Exception $e) {
			echo $e;
		}
	}
	
?>