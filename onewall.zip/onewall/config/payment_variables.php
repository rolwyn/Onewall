<?php
	
	/* Gateway 1 == DebitCredit */

	if(!defined("API_KEY")) {
		define("API_KEY", "4fad03e5a32786b37920890f645adefb");
	}

	if(!defined("AUTH_TOKEN")) {
		define("AUTH_TOKEN", "8b27da1e5790dbc5cde9674a5ca7ac1c");
	}


	/* Gateway 2 == NetBanking */

	if(!defined("API_KEY2")) {
		define("API_KEY2", "12d0986b88c8b6402f63ea1c949e1986");
	}

	if(!defined("AUTH_TOKEN2")) {
		define("AUTH_TOKEN2", "be82462bb760b10f31c18320308b155e");
	}

	if(!defined("CASHFREE_API_KEY")) {
		define("CASHFREE_API_KEY", "2413a2141550131518ce1b9142");
	}

	if(!defined("CASHFREE_AUTH_TOKEN")) {
		define("CASHFREE_AUTH_TOKEN", "5e1c71dfb8ca09e6eaf6c941574b8a3980e96a61");
	}

	if(!defined("TEST_CASHFREE_API_KEY")) {
		define("TEST_CASHFREE_API_KEY", "129ff93fe7876dd0d5848c4921");	
	}

	if(!defined("TEST_CASHFREE_AUTH_TOKEN")) {
		define("TEST_CASHFREE_AUTH_TOKEN", "1d6f7c524edec16c87878ca58be576cdabdc22c7");
	}

	if(!defined("PAYU_KEY")) {
		define("PAYU_KEY", "6gTi1p");
	}

	if(!defined("PAYU_SALT")) {
		define("PAYU_SALT", "LpxA01iC");
	}

	if(!defined("TEST_PAYU_KEY")) {
		define("TEST_PAYU_KEY", "t1dIWH");
	}

	if(!defined("TEST_PAYU_SALT")) {
		define("TEST_PAYU_SALT", "R8WZHp7p");
	}

	if(!defined("SALT")) {
		define("SALT", "0dabef30ad93401da99ddf5caf559e41");
	}

	if(!defined("GSH_SALT")) {
		define("GSH_SALT", "id0ntl1k32^ltyf006");
	}

	if(!defined("PAY_REDIRECT_URL")) {
		define("PAY_REDIRECT_URL", PROTO . $_SERVER['HTTP_HOST'] . "/api?cmd=POSTPAYMENT");
	}

	if(!defined("WEBHOOK_URL")) {
		define("WEBHOOK_URL", PROTO . $_SERVER['HTTP_HOST'] . "/ajax.php?cmd=UPDATEFAILEDTRANSACTION");
	}

	if(!defined("PAY_REDIRECT_URL_V1")) {
		define("PAY_REDIRECT_URL_V1", PROTO . $_SERVER['HTTP_HOST'] . "/api/?cmd=POSTPAYMENTV1");
	}

	if(!defined("WEBHOOK_URL_V1")) {
		define("WEBHOOK_URL_V1", PROTO . $_SERVER['HTTP_HOST'] . "/api/?cmd=POSTPAYMENTV1");
	}

	if(!defined("SERVICE_CHARGE")) {
		define("SERVICE_CHARGE", "2");
	}

	if(!defined("TOKEN_AMOUNT")) {
		define("TOKEN_AMOUNT", "2000");
	}

	if (!defined("PAY_URL")) {
		define('PAY_URL', "https://www.instamojo.com/getsethome/property-b7faa/");
	}
?>